# Aligned Probing: Relating Toxic Behavior and Model Internals


## Setting up the environment
To use this repository, please ensure your setup meets the following requirements:
* Python version 3.10.
* Install all necessary packages using pip install -r requirements.txt`.
* If you want to load language models with `four_bit,` install `bitsandbytes.` If you have trouble installing it, use the version [`0.42.0`](https://github.com/TimDettmers/bitsandbytes/tree/0.42.0) and verify the installation with `python3 -m bitsandbytes`.


## Setting up redis for experiment tracking
This repository use a redis instance for tracking experiments. You can run one with the following docker compose file and run the command `docker compose up`.

```
networks:
  tutorials:
    name: tutorials
    driver: bridge

services:
  redis:
    image: redis:latest
    ports:
    - 6379:6379
    networks:
        - tutorials
    volumes:
        - ../redis-data:/data
  redis-insight:
    image: redis/redisinsight:latest
    ports:
    - 5540:5540
    networks:
        - tutorials
```

## Update enviroment variables

Next, make sure you update the `.env` file:
- `REDIS_SERVER`: IP address of the redis server for experiment tracking
- `REDIS_PORT`: Corresponding port of the redis server
- `PERSPECTIVE_API_KEY`: The key to the perspective API
- `ENCODING_PATH`: The path to store the encodings, make sure that there is enought space > 1TB
- `RESULT_PATH`: The path to store predictions and probing models
- `CACHE_PATH`: The path to store intermediate checkpoints and results


## Run experiments

### Get text continuations and internal encodings

In a first step, we let a model complete all the prompts from our subset of the `RealToxicPrompts` dataset. Therefore run `python3 encode.py` and specific the following important arguments:

- `model_name`: Huggingface tag of the model, for the case study `Detoxification` use the corresponding detoxed version of models like `BatsResearch/llama2-7b-detox-qlora` or local pre-training checkpoints of OLMo (`olmo-hf_5000`) for the case study `Pre-Training Dynamics`
- `model_precision`: How you want to load the model, default `full` for most experiments or `four_bit` or `half` for model quantization ones, see case study `Model Quantization` 
- `encoding_batch_size`: How many prompts you want to process within one batch, lower that if you run out of memory
- `device`: Device to load the model, either `cpu` or `cuda`
- `template_index`: The template index to use (index in the file `defs/task_types.json`), default `0` or `1-4` in case of the multi-prompt experiments (see case study `Multi-Prompt Evaluation`)

### Retrieve perspective scores

Next, we retrieve the PERSPECTIVE API scores for the continuations by running `python3 attach_scores_recursive.py`.

### Probing experiments

With the encodings and the scores from PERSPECTIVE API, we can run the aligned probing experiments.

To run the main experiments, we run `python3 run_rtp.py` with the following important arguments:
- `model_name`: The huggingface tag of the encoding model you used above
- `model_precision`: The precision of the encoding model, default `full` for most experiments or `four_bit` or `half` for model quantization ones
- `device`: The index of device, for example `0` for the first 
- `template_index`: The template index to use (index in the file `defs/task_types.json`), default `0` or `1-4` in case of the multi-prompt experiments

Then we run `python3 run_rtp_mdl.py` and `python3 run_rtp_control_task.py` to verify the probing setup based on the subjectivity and compression measures, with the following parameters:
- `model_name`: The huggingface tag of the encoding model you used above
- `device`: The index of device, for example `0` for the first 


For t we run `python3 run_rtp_mdl.py` and `python3 run_rtp_control_task.py` to verify the probing setup based on the subjectivity and compression measures, with the following parameters:
- `model_name`: The huggingface tag of the encoding model you used above
- `device`: The index of device, for example `0` for the first 


### Gathering behavioral results
To get the behavioral results run `python3 gather_behavioral_results.py`.

### Gathering internal results
To get all results from probing experiments run `python3 gather_internal_results.py`.

As the above result all 